window.config = {
   "model_": "AppConfig",
   "id": 1,
   "appName": "nano",
   "homepage": "https://www.nano-editor.org",
   "kioskEnabled": true
};